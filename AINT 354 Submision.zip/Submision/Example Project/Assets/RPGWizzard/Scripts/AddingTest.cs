﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AddingTest : MonoBehaviour {

	// Use this for initialization
	void Start () {
        Debug.Log("Attached");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
